"use strict";

const byId = (id) => document.getElementById(id);
let allRecords = [];
let zoomStart = 0;
let zoomEnd = 0;
let defaultWindowActive = true;
let collectionIntervalMinutes = 60;
let chartMode = localStorage.getItem("pihole-speedtest-chart-mode") || "line";
const chartStates = new Map();
const DEFAULT_CHART_WINDOW_MS = 24 * 60 * 60 * 1000;
const BAR_GROUP_GAP_PX = 2;
const BAR_GROUP_MAX_WIDTH_PX = 56;
const PIHOLE_FONT_STACK = 'Antonio, Oswald, "Myriad Pro Cond", "Roboto Condensed", '
  + '"Futura Condensed", "Helvetica Condensed", "Arial Narrow", sans-serif';

function requestedView() {
  return window.location.hash === "#setup" ? "setup" : "overview";
}

function showView(name, updateHash = false) {
  const setup = name === "setup";
  byId("overview-view").hidden = setup;
  byId("setup-view").hidden = !setup;
  document.querySelectorAll("[data-view]").forEach((item) => item.classList.toggle("active", item.dataset.view === name));
  if (updateHash && window.location.hash !== `#${name}`) window.location.hash = name;
}

function formatNumber(value) { const n = Number(value); return Number.isFinite(n) ? n.toFixed(2) : "-"; }
function formatTime(value) { const d = new Date(value); return Number.isNaN(d.valueOf()) ? value : d.toLocaleString(); }
function formatMeasurementCount(count) { return `${count} ${count === 1 ? "measurement" : "measurements"}`; }
function hasStartTime(record) { return typeof record.started_at === "string" && Number.isFinite(Date.parse(record.started_at)); }
function hasScheduledTime(record) { return typeof record.scheduled_at === "string" && Number.isFinite(Date.parse(record.scheduled_at)); }
function chartTime(record) { return hasScheduledTime(record)
  ? record.scheduled_at : (hasStartTime(record) ? record.started_at : record.recorded_at); }
function setText(id, value) { byId(id).textContent = value; }
function addCell(row, value) { const cell = document.createElement("td"); cell.textContent = value; row.appendChild(cell); }

function renderTable(records) {
  const body = byId("results-body");
  body.replaceChildren();
  byId("empty-state").hidden = records.length > 0;
  records.slice().reverse().forEach((record) => {
    const row = document.createElement("tr");
    addCell(row, hasScheduledTime(record) ? formatTime(record.scheduled_at) : (hasStartTime(record) ? "Manual" : "Unknown (legacy)"));
    addCell(row, hasStartTime(record) ? formatTime(record.started_at) : "Unknown (legacy)");
    addCell(row, formatTime(record.recorded_at));
    addCell(row, `${formatNumber(record.download_mbps)} Mbps`);
    addCell(row, `${formatNumber(record.upload_mbps)} Mbps`);
    addCell(row, `${formatNumber(record.latency_ms)} ms`);
    addCell(row, `${formatNumber(record.jitter_ms)} ms`);
    addCell(row, record.server_name || "Not available");
    addCell(row, record.interface_name || "Not available");
    body.appendChild(row);
  });
}

function visibleRecords() { return allRecords.slice(zoomStart, zoomEnd); }
function chartMaximum(records, series, minimum) {
  const values = series.flatMap((item) => records.map((record) => Number(record[item.field]) || 0));
  return Math.ceil(Math.max(minimum, ...values) * 1.1);
}

function chartTimeline(records) {
  const intervalMs = collectionIntervalMinutes * 60 * 1000;
  const timestamps = records.map((record) => Date.parse(chartTime(record)));
  const valid = timestamps.filter(Number.isFinite);
  const deltas = [];
  for (let index = 1; index < timestamps.length; index += 1) {
    const elapsed = timestamps[index] - timestamps[index - 1];
    if (Number.isFinite(elapsed) && elapsed > 0) deltas.push(elapsed);
  }
  deltas.sort((left, right) => left - right);
  const medianDelta = deltas.length
    ? deltas[Math.floor((deltas.length - 1) / 2)]
    : intervalMs;
  const cadenceMs = Math.max(intervalMs, medianDelta);
  const first = valid.length ? Math.min(...valid) : 0;
  const last = valid.length ? Math.max(...valid) : first;
  let start = records.length === 1 ? first - intervalMs / 2 : first;
  let end = records.length === 1 ? last + intervalMs / 2 : last;
  if (defaultWindowActive && valid.length) {
    end = last;
    start = end - DEFAULT_CHART_WINDOW_MS;
  }
  return {
    timestamps,
    start,
    end,
    duration: Math.max(end - start, 1),
    intervalMs,
    cadenceMs,
    gapThresholdMs: cadenceMs * 2.5,
  };
}

function formatAxisTime(timestamp) {
  return new Date(timestamp).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

function chartNote(records) {
  if (defaultWindowActive) return `${formatMeasurementCount(records.length)} - last 24 hours`;
  return records.length === allRecords.length
    ? formatMeasurementCount(records.length)
    : `${formatMeasurementCount(records.length)} shown of ${allRecords.length}`;
}

function chartBarSpacing(timeline, xPositions) {
  const spacings = [];
  for (let index = 1; index < xPositions.length; index += 1) {
    const previous = timeline.timestamps[index - 1];
    const current = timeline.timestamps[index];
    if (!Number.isFinite(previous) || !Number.isFinite(current)) continue;
    const elapsed = current - previous;
    if (elapsed <= 0 || elapsed > timeline.cadenceMs * 1.5) continue;
    const spacing = xPositions[index] - xPositions[index - 1];
    if (spacing > 0) spacings.push(spacing);
  }
  if (spacings.length === 0) return Infinity;
  spacings.sort((left, right) => left - right);
  const middle = Math.floor(spacings.length / 2);
  return spacings.length % 2
    ? spacings[middle]
    : (spacings[middle - 1] + spacings[middle]) / 2;
}

function chartBarGroupWidth(timeline, chartWidth, measuredSpacing) {
  const expectedSpacing = chartWidth * timeline.intervalMs / timeline.duration;
  const availableSpacing = Math.min(expectedSpacing, measuredSpacing);
  const reservedGap = Math.min(BAR_GROUP_GAP_PX, availableSpacing * 0.5);
  return Math.max(0.1, Math.min(BAR_GROUP_MAX_WIDTH_PX, availableSpacing - reservedGap));
}

function chartTimeTicks(timeline, chartWidth) {
  const hourMs = 60 * 60 * 1000;
  const durationHours = timeline.duration / hourMs;
  const targetTicks = Math.max(2, Math.floor(chartWidth / 64));
  const minimumHours = durationHours / targetTicks;
  const stepHours = [1, 2, 3, 4, 6, 12, 24, 48, 72, 168]
    .find((candidate) => candidate >= minimumHours) || 168;
  const stepMs = stepHours * hourMs;
  const firstTick = Math.ceil(timeline.start / stepMs) * stepMs;
  const ticks = [];
  for (let timestamp = firstTick; timestamp <= timeline.end; timestamp += stepMs) {
    ticks.push(timestamp);
  }
  return ticks;
}

function drawBarGroup(context, x, chartBottom, bars, groupWidth) {
  const heights = bars.map((bar) => bar.height);
  const nearlyEqual = Math.max(...heights) - Math.min(...heights) <= 3;
  if (nearlyEqual) {
    const seriesGap = bars.length > 1
      ? Math.min(2, Math.max(0.5, groupWidth * 0.08))
      : 0;
    const barWidth = Math.max(
      0.1,
      (groupWidth - seriesGap * (bars.length - 1)) / bars.length,
    );
    const renderedGroupWidth = barWidth * bars.length + seriesGap * (bars.length - 1);
    bars.forEach((bar, index) => {
      context.fillStyle = bar.color;
      context.fillRect(
        x - renderedGroupWidth / 2 + index * (barWidth + seriesGap),
        chartBottom - bar.height,
        barWidth,
        bar.height,
      );
    });
    return;
  }

  bars.slice().sort((left, right) => right.height - left.height).forEach((bar, index) => {
    const layerWidth = index === 0
      ? groupWidth
      : Math.max(0.1, groupWidth * Math.max(0.42, 0.68 - (index - 1) * 0.12));
    context.fillStyle = bar.color;
    context.fillRect(x - layerWidth / 2, chartBottom - bar.height, layerWidth, bar.height);
  });
}

function drawChart(records, options) {
  const canvas = byId(options.canvasId);
  const ratio = window.devicePixelRatio || 1;
  const width = Math.max(canvas.clientWidth, 320);
  const height = 280;
  canvas.width = width * ratio;
  canvas.height = height * ratio;
  const context = canvas.getContext("2d");
  context.scale(ratio, ratio);
  context.clearRect(0, 0, width, height);
  if (records.length === 0) {
    setText(options.noteId, "No measurements");
    chartStates.delete(options.canvasId);
    byId(options.tooltipId).hidden = true;
    return;
  }

  const plottedRecords = records;
  const timeline = chartTimeline(plottedRecords);
  setText(options.noteId, chartNote(records));
  const padding = { top: 20, right: 16, bottom: 34, left: 46 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  const maximum = chartMaximum(plottedRecords, options.series, options.minimumMaximum);
  const values = options.series.map((series) => plottedRecords.map((record) => Number(record[series.field]) || 0));
  const xForTimestamp = (timestamp) => padding.left + chartWidth * (timestamp - timeline.start) / timeline.duration;
  const xPositions = timeline.timestamps.map((timestamp, index) => Number.isFinite(timestamp)
    ? xForTimestamp(timestamp)
    : padding.left + chartWidth * index / Math.max(plottedRecords.length - 1, 1));
  chartStates.set(options.canvasId, { records: plottedRecords, options, padding, chartWidth, chartHeight, xPositions });
  context.strokeStyle = "#263747";
  context.fillStyle = "#8fa4b8";
  context.font = `400 12px ${PIHOLE_FONT_STACK}`;
  context.lineWidth = 1;
  for (let line = 0; line <= 4; line += 1) {
    const y = padding.top + chartHeight * line / 4;
    context.beginPath(); context.moveTo(padding.left, y); context.lineTo(width - padding.right, y); context.stroke();
    context.fillText((maximum - maximum * line / 4).toFixed(0), 7, y + 4);
  }

  const timeTicks = chartTimeTicks(timeline, chartWidth);
  context.fillStyle = "#8fa4b8";
  context.font = `400 11px ${PIHOLE_FONT_STACK}`;
  timeTicks.forEach((timestamp) => {
    const label = formatAxisTime(timestamp);
    const x = xForTimestamp(timestamp);
    context.strokeStyle = "#202d39";
    context.beginPath(); context.moveTo(x, padding.top); context.lineTo(x, padding.top + chartHeight); context.stroke();
    context.fillStyle = "#8fa4b8";
    context.textAlign = "center";
    context.fillText(label, x, height - 7);
  });
  context.textAlign = "start";

  if (chartMode === "bar") {
    const measuredSpacing = chartBarSpacing(timeline, xPositions);
    plottedRecords.forEach((record, index) => {
      const nearestSpacing = Math.min(
        index > 0 ? xPositions[index] - xPositions[index - 1] : Infinity,
        index + 1 < xPositions.length ? xPositions[index + 1] - xPositions[index] : Infinity,
      );
      const groupWidth = chartBarGroupWidth(
        timeline, chartWidth, Math.min(measuredSpacing, nearestSpacing),
      );
      const bars = options.series.map((series, seriesIndex) => ({
        color: series.color,
        height: chartHeight * values[seriesIndex][index] / maximum,
      }));
      drawBarGroup(
        context,
        xPositions[index],
        padding.top + chartHeight,
        bars,
        groupWidth,
      );
    });
    return;
  }

  options.series.forEach((series, seriesIndex) => {
    const points = [];
    context.strokeStyle = series.color; context.lineWidth = 2.5; context.beginPath();
    values[seriesIndex].forEach((value, index) => {
      const x = xPositions[index];
      const y = padding.top + chartHeight - chartHeight * value / maximum;
      const previous = index > 0 ? timeline.timestamps[index - 1] : null;
      const current = timeline.timestamps[index];
      const elapsed = current - previous;
      const breaksLine = index === 0 || !Number.isFinite(previous) ||
        !Number.isFinite(current) || elapsed > timeline.gapThresholdMs;
      points.push({ x, y }); breaksLine ? context.moveTo(x, y) : context.lineTo(x, y);
    });
    context.stroke(); context.fillStyle = series.color;
    points.forEach(({ x, y }) => { context.beginPath(); context.arc(x, y, 4, 0, Math.PI * 2); context.fill(); });
  });
}

function renderCharts() {
  const records = visibleRecords();
  drawChart(records, { canvasId: "history-chart", tooltipId: "history-tooltip", noteId: "chart-note", minimumMaximum: 10,
    series: [
      { field: "download_mbps", label: "Download", unit: "Mbps", color: "#66c2ff" },
      { field: "upload_mbps", label: "Upload", unit: "Mbps", color: "#62d49d" },
    ] });
  drawChart(records, { canvasId: "latency-chart", tooltipId: "latency-tooltip", noteId: "latency-chart-note", minimumMaximum: 10,
    series: [
      { field: "latency_ms", label: "Latency", unit: "ms", color: "#ffb86b" },
      { field: "jitter_ms", label: "Jitter", unit: "ms", color: "#c792ea" },
    ] });
}

function hideChartTooltip(canvas) {
  const state = chartStates.get(canvas.id);
  if (state) byId(state.options.tooltipId).hidden = true;
}

function showChartTooltip(event, canvas) {
  const state = chartStates.get(canvas.id);
  if (!state || state.records.length === 0) return;
  const bounds = canvas.getBoundingClientRect();
  const x = event.clientX - bounds.left;
  const y = event.clientY - bounds.top;
  const { padding, chartWidth, chartHeight, records, options, xPositions } = state;
  if (x < padding.left || x > padding.left + chartWidth || y < padding.top || y > padding.top + chartHeight) {
    hideChartTooltip(canvas);
    return;
  }

  const index = xPositions.reduce((nearest, position, candidate) => (
    Math.abs(position - x) < Math.abs(xPositions[nearest] - x) ? candidate : nearest
  ), 0);
  const record = records[index];
  const tooltip = byId(options.tooltipId);
  const title = document.createElement("strong");
  title.textContent = hasScheduledTime(record)
    ? `Scheduled: ${formatTime(record.scheduled_at)}`
    : (hasStartTime(record)
      ? `Started: ${formatTime(record.started_at)}`
      : `Recorded: ${formatTime(record.recorded_at)} (start unknown)`);
  const started = document.createElement("span");
  if (hasScheduledTime(record) && hasStartTime(record)) started.textContent = `Started: ${formatTime(record.started_at)}`;
  const completed = document.createElement("span");
  if (hasStartTime(record)) completed.textContent = `Completed: ${formatTime(record.recorded_at)}`;
  const rows = options.series.map((series) => {
    const row = document.createElement("span");
    const swatch = document.createElement("i");
    swatch.style.background = series.color;
    row.append(swatch, `${series.label}: ${formatNumber(record[series.field])} ${series.unit}`);
    return row;
  });
  tooltip.replaceChildren(title, ...(hasScheduledTime(record) && hasStartTime(record) ? [started] : []),
    ...(hasStartTime(record) ? [completed] : []), ...rows);
  tooltip.style.left = `${Math.max(105, Math.min(bounds.width - 105, x))}px`;
  tooltip.style.top = `${Math.max(96, y)}px`;
  tooltip.hidden = false;
}

function changeZoom(action) {
  const total = allRecords.length;
  if (total < 2) return;
  if (action === "reset") { setDefaultZoomRange(); }
  else {
    defaultWindowActive = false;
    const current = zoomEnd - zoomStart;
    const next = action === "in" ? Math.max(5, Math.floor(current * 0.75)) : Math.min(total, Math.ceil(current / 0.75));
    const center = (zoomStart + zoomEnd) / 2;
    zoomStart = Math.max(0, Math.round(center - next / 2)); zoomEnd = Math.min(total, zoomStart + next);
    zoomStart = Math.max(0, zoomEnd - next);
  }
  renderCharts();
}

function panZoom(deltaPixels, width) {
  const visible = zoomEnd - zoomStart;
  if (visible >= allRecords.length || width <= 0) return;
  const shift = Math.round(-deltaPixels / width * visible);
  const nextStart = Math.max(0, Math.min(allRecords.length - visible, zoomStart + shift));
  defaultWindowActive = false;
  zoomStart = nextStart; zoomEnd = nextStart + visible; renderCharts();
}

function setDefaultZoomRange() {
  zoomEnd = allRecords.length;
  if (!allRecords.length) {
    zoomStart = 0;
    defaultWindowActive = true;
    return;
  }
  const latest = Date.parse(chartTime(allRecords[allRecords.length - 1]));
  const cutoff = latest - DEFAULT_CHART_WINDOW_MS;
  const firstVisible = allRecords.findIndex((record) => Date.parse(chartTime(record)) >= cutoff);
  zoomStart = firstVisible < 0 ? Math.max(0, allRecords.length - 1) : firstVisible;
  defaultWindowActive = true;
}

async function postJson(path, payload) {
  return fetch(path, { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload) });
}

function setCollectionMessage(value) {
  setText("collection-message", value);
}

function setCollectionButtonsDisabled(disabled) {
  document.querySelectorAll("[data-run-speedtest]").forEach((button) => { button.disabled = disabled; });
}

async function waitForCollection() {
  for (let attempt = 0; attempt < 190; attempt += 1) {
    await new Promise((resolve) => window.setTimeout(resolve, 1000));
    const response = await fetch("/api/collection-status", { cache: "no-store" });
    const status = await response.json();
    if (status.state === "running") { setCollectionMessage(status.message); continue; }
    setCollectionButtonsDisabled(false);
    setCollectionMessage(status.message || "Speed test finished.");
    if (status.state === "succeeded") await load();
    return;
  }
  setCollectionButtonsDisabled(false);
  setCollectionMessage("The speed test is still running. Check status again shortly.");
}

async function runSpeedtest() {
  setCollectionButtonsDisabled(true);
  setCollectionMessage("Starting an official Ookla speed test.");
  try {
    const response = await postJson("/api/collect", {});
    const result = await response.json();
    if (!response.ok) {
      setCollectionButtonsDisabled(false);
      setCollectionMessage(result.error || "The speed test could not be started.");
      return;
    }
    setCollectionMessage(result.message);
    await waitForCollection();
  } catch (error) {
    setCollectionButtonsDisabled(false);
    setCollectionMessage("The dashboard could not start the speed test.");
  }
}

function installControls() {
  if (new URLSearchParams(window.location.search).get("embed") === "1") document.body.classList.add("embedded");
  showView(requestedView());
  window.addEventListener("hashchange", () => showView(requestedView()));
  const helpDialog = byId("help-dialog");
  byId("open-help").addEventListener("click", () => helpDialog.showModal());
  byId("close-help").addEventListener("click", () => helpDialog.close());
  helpDialog.addEventListener("click", (event) => {
    if (event.target === helpDialog) helpDialog.close();
  });
  document.querySelectorAll("[data-view]").forEach((button) => button.addEventListener("click", () => {
    showView(button.dataset.view, true);
  }));
  document.querySelectorAll("[data-chart-mode]").forEach((button) => {
    button.classList.toggle("active", button.dataset.chartMode === chartMode);
    button.addEventListener("click", () => {
      chartMode = button.dataset.chartMode; localStorage.setItem("pihole-speedtest-chart-mode", chartMode);
      document.querySelectorAll("[data-chart-mode]").forEach((item) => item.classList.toggle("active", item === button));
      renderCharts();
    });
  });
  document.querySelectorAll("[data-zoom]").forEach((button) => button.addEventListener("click", () => changeZoom(button.dataset.zoom)));
  document.querySelectorAll("canvas").forEach((canvas) => {
    let dragStart = null;
    canvas.addEventListener("pointermove", (event) => {
      if (dragStart === null) showChartTooltip(event, canvas);
    });
    canvas.addEventListener("pointerleave", () => hideChartTooltip(canvas));
    canvas.addEventListener("wheel", (event) => {
      event.preventDefault(); changeZoom(event.deltaY < 0 ? "in" : "out");
    }, { passive: false });
    canvas.addEventListener("pointerdown", (event) => {
      hideChartTooltip(canvas);
      dragStart = event.clientX; canvas.setPointerCapture(event.pointerId);
    });
    canvas.addEventListener("pointerup", (event) => {
      if (dragStart !== null) panZoom(event.clientX - dragStart, canvas.clientWidth);
      dragStart = null;
    });
    canvas.addEventListener("pointercancel", () => { dragStart = null; });
  });

  const showTable = byId("show-table");
  showTable.checked = localStorage.getItem("pihole-speedtest-show-table") !== "false";
  byId("measurement-table").hidden = !showTable.checked;
  showTable.addEventListener("change", () => {
    localStorage.setItem("pihole-speedtest-show-table", String(showTable.checked));
    byId("measurement-table").hidden = !showTable.checked;
  });
  byId("save-frequency").addEventListener("click", async () => {
    const response = await postJson("/api/settings", { collection_interval_minutes: Number(byId("collection-frequency").value) });
    const result = await response.json(); setText("settings-message", response.ok ? "Capture frequency saved." : result.error);
  });
  document.querySelectorAll("[data-run-speedtest]").forEach((button) => {
    button.addEventListener("click", runSpeedtest);
  });
  const updateResetButton = () => { byId("reset-data").disabled = !byId("reset-acknowledgement").checked || byId("reset-confirmation").value !== "RESET"; };
  byId("reset-acknowledgement").addEventListener("change", updateResetButton);
  byId("reset-confirmation").addEventListener("input", updateResetButton);
  byId("reset-data").addEventListener("click", async () => {
    const response = await postJson("/api/reset", { confirmation: "RESET" });
    const result = await response.json();
    setText("reset-message", response.ok ? `History reset. Recovery backup: ${result.backup}` : result.error);
    if (response.ok) await load();
  });
}

async function load() {
  const healthElement = byId("health");
  try {
    const [healthResponse, resultsResponse, settingsResponse] = await Promise.all([
      fetch("/api/health", { cache: "no-store" }), fetch("/api/results?limit=100", { cache: "no-store" }),
      fetch("/api/settings", { cache: "no-store" }),
    ]);
    if (!healthResponse.ok || !resultsResponse.ok || !settingsResponse.ok) throw new Error("Dashboard API returned an error");
    const health = await healthResponse.json(); const results = await resultsResponse.json(); const settings = await settingsResponse.json();
    allRecords = Array.isArray(results.records) ? results.records : [];
    setDefaultZoomRange();
    collectionIntervalMinutes = Number(settings.collection_interval_minutes) || 60;
    byId("collection-frequency").value = String(settings.collection_interval_minutes);
    const latest = allRecords[allRecords.length - 1];
    healthElement.textContent = `Healthy - ${formatMeasurementCount(health.measurements)}`; healthElement.className = "health ok";
    setText("app-version", `version ${health.version}`);
    if (latest) { setText("latest-download", formatNumber(latest.download_mbps)); setText("latest-upload", formatNumber(latest.upload_mbps)); setText("latest-latency", formatNumber(latest.latency_ms)); setText("latest-jitter", formatNumber(latest.jitter_ms)); }
    if (document.fonts?.ready) await document.fonts.ready;
    renderTable(allRecords); renderCharts();
  } catch (error) {
    healthElement.textContent = "Dashboard unavailable"; healthElement.className = "health error";
    setText("chart-note", "Could not load results"); setText("latency-chart-note", "Could not load results");
  }
}

window.addEventListener("resize", () => { window.clearTimeout(window.__resizeTimer); window.__resizeTimer = window.setTimeout(renderCharts, 120); });
installControls(); load();
